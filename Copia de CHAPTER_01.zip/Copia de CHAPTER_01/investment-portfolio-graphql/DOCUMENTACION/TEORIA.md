# 📚 CAPÍTULO 1: FUNDAMENTOS DE GRAPHQL Y CONTEXTO CORPORATIVO

**Duración:** 2.5 horas (5 secciones × 30 min)  
**Objetivo:** Comprender por qué GraphQL existe, qué problemas resuelve y cómo implementarlo profesionalmente

---

## 📖 ÍNDICE DE CONTENIDOS

1. [Sección 1.1 - De REST a GraphQL](#sección-11---de-rest-a-graphql)
2. [Sección 1.2 - Componentes y lenguaje base](#sección-12---componentes-y-lenguaje-base)
3. [Sección 1.3 - Consultas anidadas y uso de variables](#sección-13---consultas-anidadas-y-uso-de-variables)
4. [Sección 1.4 - Filtros orden y paginación](#sección-14---filtros-orden-y-paginación)
5. [Sección 1.5 - Tipado nullabilidad y seguridad básica](#sección-15---tipado-nullabilidad-y-seguridad-básica)

---

# Sección 1.1 - De REST a GraphQL

**Duración:** 30 minutos

## 🎯 Objetivo

Contextualizar el origen de GraphQL frente a las limitaciones del modelo REST tradicional. Comprender los problemas de **overfetching** y **underfetching** en arquitecturas distribuidas, especialmente en ecosistemas bancarios donde la eficiencia en la comunicación entre microservicios es crítica.

---

## 1. El Problema con REST en Arquitecturas Distribuidas

### 1.1 Contexto: Arquitectura de Microservicios Bancaria

En un ecosistema bancario moderno (NeoBank), típicamente encontramos:

```
┌─────────────────┐     ┌─────────────────┐     ┌─────────────────┐
│   Portfolio     │     │     Assets      │     │   Performance   │
│   Service       │────▶│    Service      │────▶│    Service      │
└─────────────────┘     └─────────────────┘     └─────────────────┘
```

**Problema:** Cliente mobile necesita mostrar una vista de portfolio completo con assets y performance.

### 1.2 Overfetching: El Cliente Recibe MÁS de lo Necesario

**Definición:** El servidor retorna datos que el cliente NO necesita.

**Ejemplo REST:**
```http
GET /api/portfolios
```

**Respuesta (JSON):**
```json
[
  {
    "id": "portfolio-001",
    "name": "Growth Portfolio",
    "ownerId": "user-001",
    "ownerName": "Carlos Mendoza",
    "ownerEmail": "carlos@example.com",        ← NO necesario
    "ownerAddress": "...",                     ← NO necesario
    "createdAt": "2025-01-15",
    "lastModified": "2025-11-15",              ← NO necesario
    "totalValue": 59013.75,
    "assets": [ /* 20 campos por asset */ ],   ← Muchos NO necesarios
    "performance": { /* 15 campos */ },        ← Muchos NO necesarios
    "metadata": { /* ... */ }                  ← NO necesario
  }
]
```

**Problema:**
- Cliente solo necesita `name` y `totalValue`
- Servidor envía **100+ campos innecesarios**
- **Desperdicio de bandwidth:** ~50KB cuando solo necesitaba ~1KB
- **Latencia:** Parsear JSON gigante es costoso en mobile
- **Costo:** Más datos = más dinero en cloud providers

**Impacto en NeoBank:**
- Millones de usuarios en mobile
- Conexiones 3G/4G limitadas
- UX lenta = abandono de usuarios

---

### 1.3 Underfetching: El Cliente Recibe MENOS de lo Necesario

**Definición:** El cliente necesita hacer MÚLTIPLES llamadas HTTP para obtener todos los datos relacionados.

**Ejemplo REST:**

**Paso 1:** Obtener portfolio
```http
GET /api/portfolios/portfolio-001
```

**Paso 2:** Obtener assets del portfolio
```http
GET /api/portfolios/portfolio-001/assets
```

**Paso 3:** Obtener performance del portfolio
```http
GET /api/portfolios/portfolio-001/performance
```

**Problema:**
- **3 llamadas HTTP** (3 × round-trip time)
- En red lenta: 3 × 200ms = **600ms de latencia**
- **Waterfall effect:** Una llamada depende de la anterior
- **Complejidad en cliente:** Orquestar múltiples requests
- **Error handling complejo:** ¿Qué pasa si una falla?

**Diagrama de tiempo:**
```
Cliente                        Servidor
  │                               │
  │────── GET /portfolios ───────▶│
  │                               │
  │◀────── Response ──────────────│  (200ms)
  │                               │
  │─── GET /portfolios/001/assets─▶│
  │                               │
  │◀────── Response ──────────────│  (200ms)
  │                               │
  │── GET /portfolios/001/perf ───▶│
  │                               │
  │◀────── Response ──────────────│  (200ms)
  │                               │
Total: 600ms + procesamiento
```

---

## 2. La Solución: GraphQL

### 2.1 Endpoint Único

**REST:** Múltiples endpoints especializados
```
GET /api/portfolios
GET /api/portfolios/{id}
GET /api/portfolios/{id}/assets
GET /api/portfolios/{id}/performance
POST /api/portfolios
PUT /api/portfolios/{id}
DELETE /api/portfolios/{id}
...
```

**GraphQL:** UN solo endpoint
```
POST /graphql
```

**Ventaja:** Toda la lógica de consulta está en el cliente, no en URLs del servidor.

---

### 2.2 GraphQL Resuelve Overfetching: El Cliente DECLARA lo que Necesita

**Query GraphQL:**
```graphql
{
  myPortfolios {
    name
    totalValue
  }
}
```

**Respuesta (EXACTAMENTE lo pedido):**
```json
{
  "data": {
    "myPortfolios": [
      {
        "name": "Growth Portfolio",
        "totalValue": 59013.75
      }
    ]
  }
}
```

**Beneficios:**
- ✅ Solo 2 campos retornados
- ✅ ~100 bytes vs ~50KB de REST
- ✅ 500x menos datos transferidos
- ✅ Parsing más rápido en cliente
- ✅ Mejor UX (carga más rápida)

---

### 2.3 GraphQL Resuelve Underfetching: Una Sola Query para Datos Relacionados

**Query GraphQL (TODO en UNA llamada):**
```graphql
{
  portfolio(id: "portfolio-001") {
    name
    totalValue
    assets {
      symbol
      currentPrice
      quantity
    }
    performance {
      totalReturn
      yearReturn
      bestPerformer {
        symbol
        profitLossPercent
      }
    }
  }
}
```

**Resultado:**
- ✅ **1 llamada HTTP** vs 3 de REST
- ✅ ~200ms total vs ~600ms de REST
- ✅ **3x más rápido**
- ✅ Datos anidados en una sola respuesta
- ✅ Menor complejidad en cliente

**Diagrama de tiempo:**
```
Cliente                        Servidor
  │                               │
  │────── POST /graphql ──────────▶│
  │  (query con portfolio,         │
  │   assets y performance)        │
  │                               │
  │◀────── Response completa ─────│  (200ms)
  │                               │
Total: 200ms + procesamiento
```

---

### 2.4 Declarativo vs Imperativo

**REST (Imperativo):**
El servidor decide qué datos devolver basado en la URL.

```javascript
// Cliente RECIBE lo que el servidor decidió
const response = await fetch('/api/portfolios');
// No puedo elegir qué campos recibir
```

**GraphQL (Declarativo):**
El cliente DECLARA exactamente lo que necesita.

```graphql
# Cliente PIDE solo lo que necesita
{
  myPortfolios {
    name        # Solo estos 2 campos
    totalValue  # Nada más
  }
}
```

**Analogía:**
- **REST:** Como un menú de restaurante fijo (recibes lo que está en el combo)
- **GraphQL:** Como un buffet (eliges exactamente lo que quieres)

---

## 3. Ventajas Adicionales de GraphQL

### 3.1 Reducción de Tráfico de Red

**Caso real NeoBank:**
- 1 millón de requests diarios
- REST: 50KB promedio por request
- GraphQL: 5KB promedio por request

**Ahorro:**
```
REST:    1M × 50KB = 50GB/día
GraphQL: 1M × 5KB  = 5GB/día
Ahorro:  45GB/día  = 1.35TB/mes
```

**Costo en AWS:**
- ~$120 USD/mes de ahorro en bandwidth
- ~$1,440 USD/año

### 3.2 Simplificación de Contratos

**REST:**
```
Backend Dev: "Necesito crear 7 endpoints nuevos para mobile"
Frontend Dev: "¿Cuándo estarán listos?"
Backend Dev: "2 semanas..."
Frontend Dev: "Pero necesito 2 campos más en /portfolios"
Backend Dev: "Eso rompe backward compatibility... versión 2 de la API"
```

**GraphQL:**
```
Backend Dev: "El schema está publicado, pide lo que necesites"
Frontend Dev: "Genial, agrego 2 campos a mi query"
Backend Dev: "Ya funciona. Sin cambios en mi lado"
```

### 3.3 Mantenibilidad del Backend

**REST:** Proliferación de endpoints
```
/api/v1/portfolios
/api/v1/portfolios/summary           ← mobile
/api/v1/portfolios/full              ← web
/api/v1/portfolios/dashboard         ← tablet
/api/v1/portfolios/export            ← reporting
...
```

**GraphQL:** Un schema, múltiples clientes
```graphql
type Portfolio {
  # Todos los campos disponibles
  # Cada cliente pide lo que necesita
}
```

---

## 4. Comparación REST vs GraphQL

### 4.1 Tabla Comparativa

| Aspecto | REST | GraphQL |
|---------|------|---------|
| **Endpoints** | Múltiples (`/users`, `/posts`, etc.) | Uno solo (`/graphql`) |
| **Overfetching** | ❌ Común (servidor decide campos) | ✅ Eliminado (cliente decide) |
| **Underfetching** | ❌ Común (múltiples requests) | ✅ Eliminado (una query) |
| **Versioning** | ❌ Necesario (`/api/v1`, `/api/v2`) | ✅ No necesario (campos deprecated) |
| **Documentación** | ⚠️ Manual (Swagger, etc.) | ✅ Auto-generada (introspection) |
| **Type Safety** | ⚠️ Depende (TypeScript, etc.) | ✅ Built-in (schema types) |
| **Caching** | ✅ HTTP cache funciona bien | ⚠️ Más complejo (pero solucionable) |
| **Curva de aprendizaje** | ✅ Baja (HTTP estándar) | ⚠️ Media (nuevo paradigma) |

### 4.2 Cuándo Usar REST vs GraphQL

**Usar REST cuando:**
- ✅ API pública simple con pocos endpoints
- ✅ CRUD básico sin relaciones complejas
- ✅ Caching HTTP es crítico
- ✅ Equipo sin experiencia en GraphQL

**Usar GraphQL cuando:**
- ✅ Múltiples clientes con necesidades diferentes (mobile, web, tablet)
- ✅ Datos altamente relacionados (grafos)
- ✅ Necesitas flexibilidad sin versionar API
- ✅ Arquitectura de microservicios
- ✅ Performance de red es crítica

---

## 5. Ejemplos Comparativos (NeoBank)

### Ejemplo 1: Vista de Portfolio Simple

**Necesidad:** Mostrar solo nombre y valor total.

**REST:**
```http
GET /api/portfolios

Response: 50KB (todo el objeto Portfolio)
```

**GraphQL:**
```graphql
{
  myPortfolios {
    name
    totalValue
  }
}

Response: 0.5KB (solo lo pedido)
```

**Resultado:** 100x menos datos.

---

### Ejemplo 2: Vista de Portfolio Completo

**Necesidad:** Portfolio + Assets + Performance.

**REST:**
```http
1. GET /api/portfolios/portfolio-001       (200ms)
2. GET /api/portfolios/portfolio-001/assets (200ms)
3. GET /api/portfolios/portfolio-001/performance (200ms)

Total: 600ms + 3 requests
```

**GraphQL:**
```graphql
{
  portfolio(id: "portfolio-001") {
    name
    assets { symbol price }
    performance { totalReturn }
  }
}

Total: 200ms + 1 request
```

**Resultado:** 3x más rápido.

---

### Ejemplo 3: Dashboard Personalizado

**Necesidad:** Cada usuario quiere ver diferentes métricas.

**REST:**
```http
# Usuario 1: necesita A, B, C
GET /api/dashboard/type1

# Usuario 2: necesita B, D, E
GET /api/dashboard/type2

# Usuario 3: necesita A, D, F
GET /api/dashboard/type3

→ Backend mantiene 3+ endpoints
```

**GraphQL:**
```graphql
# Usuario 1
{ portfolio { A B C } }

# Usuario 2
{ portfolio { B D E } }

# Usuario 3
{ portfolio { A D F } }

→ Backend mantiene 1 schema
```

**Resultado:** Mantenimiento simplificado.

---

## 6. Conceptos Clave

### 6.1 Endpoint Único

GraphQL usa **UN solo endpoint HTTP** (típicamente `/graphql`) para todas las operaciones.

**Por qué:**
- La consulta está en el BODY del request, no en la URL
- El servidor interpreta la query y retorna lo solicitado
- Simplifica routing y versionado

### 6.2 Lenguaje de Consulta

GraphQL es un **lenguaje** para describir qué datos necesitas.

```graphql
# Sintaxis declarativa
{
  portfolio(id: "001") {
    name
    assets {
      symbol
    }
  }
}
```

### 6.3 Schema como Contrato

El **schema** define qué es posible consultar.

```graphql
type Portfolio {
  id: ID!
  name: String!
  totalValue: Float!
  assets: [Asset!]!
}
```

Cliente y servidor comparten este contrato explícito.

---

## 7. Resumen de Sección 1.1

### Problemas de REST que GraphQL resuelve:

1. **Overfetching** → Cliente recibe solo lo que pide
2. **Underfetching** → Una query obtiene datos relacionados
3. **Múltiples endpoints** → Un endpoint único
4. **Versionado complejo** → Schema evolutivo sin versiones
5. **Contratos implícitos** → Schema explícito y tipado

### Beneficios clave:

- ✅ **Menos tráfico de red** (hasta 100x reducción)
- ✅ **Menos latencia** (1 request vs múltiples)
- ✅ **Mayor flexibilidad** para clientes
- ✅ **Mejor mantenibilidad** del backend
- ✅ **Desarrollo más rápido** (sin esperar nuevos endpoints)

---

# Sección 1.2 - Componentes y lenguaje base

**Duración:** 30 minutos

## 🎯 Objetivo

Introducir los cinco pilares del lenguaje GraphQL: **Schema, Types, Queries, Mutations y Resolvers**. Comprender cómo el schema actúa como contrato explícito entre cliente y servidor, describiendo los tipos disponibles y las operaciones posibles.

---

## 1. Los Cinco Pilares de GraphQL

```
┌─────────────────────────────────────────┐
│           1. SCHEMA                     │
│  (Contrato explícito)                   │
│                                         │
│  ┌────────────────────────────────┐    │
│  │     2. TYPES                   │    │
│  │  (Portfolio, Asset, etc.)      │    │
│  └────────────────────────────────┘    │
│                                         │
│  ┌─────────────┐  ┌──────────────┐    │
│  │ 3. QUERIES  │  │ 4. MUTATIONS │    │
│  │  (leer)     │  │  (escribir)  │    │
│  └─────────────┘  └──────────────┘    │
│                                         │
│  ┌────────────────────────────────┐    │
│  │     5. RESOLVERS               │    │
│  │  (lógica de conexión)          │    │
│  └────────────────────────────────┘    │
└─────────────────────────────────────────┘
```

---

## 2. Pilar #1: Schema

### 2.1 Definición

El **schema** es el contrato explícito que define:
- Qué tipos de datos existen
- Qué operaciones se pueden realizar
- Qué campos tiene cada tipo
- Qué argumentos acepta cada operación

**Analogía:** Es como un "API specification" pero mucho más poderoso porque es **ejecutable** y **validable**.

### 2.2 Ejemplo: Schema Investment Portfolio

```graphql
# Archivo: schema.graphqls

# Tipo raíz de queries (lecturas)
type Query {
  # Obtener todos mis portfolios
  myPortfolios: [Portfolio!]!
  
  # Obtener un portfolio específico por ID
  portfolio(id: ID!): Portfolio
  
  # Buscar un asset por símbolo
  searchAsset(symbol: String!): Asset
}

# Tipo raíz de mutations (escrituras)
type Mutation {
  # Crear un nuevo portfolio
  createPortfolio(input: CreatePortfolioInput!): PortfolioResponse!
  
  # Agregar un asset a un portfolio
  addAsset(input: AddAssetInput!): AssetResponse!
  
  # Remover un asset de un portfolio
  removeAsset(portfolioId: ID!, assetId: ID!): AssetResponse!
}

# Tipo de dominio: Portfolio
type Portfolio {
  id: ID!
  name: String!
  ownerId: ID!
  ownerName: String!
  totalValue: Float!
  createdAt: String!
  assets: [Asset!]!
  performance: Performance!
}

# Tipo de dominio: Asset
type Asset {
  id: ID!
  symbol: String!
  name: String!
  assetType: AssetType!
  quantity: Float!
  averageBuyPrice: Float!
  currentPrice: Float!
  totalValue: Float!
  profitLossPercent: Float!
}

# Tipo de dominio: Performance
type Performance {
  totalReturn: Float!
  yearReturn: Float!
  monthReturn: Float!
  weekReturn: Float!
  bestPerformer: Asset
  worstPerformer: Asset
}

# Enum: Tipos de assets
enum AssetType {
  STOCK
  CRYPTO
  ETF
  BOND
  COMMODITY
}

# Input para crear portfolio
input CreatePortfolioInput {
  name: String!
}

# Input para agregar asset
input AddAssetInput {
  portfolioId: ID!
  symbol: String!
  assetType: AssetType!
  quantity: Float!
  buyPrice: Float!
}

# Response wrapper
type PortfolioResponse {
  success: Boolean!
  message: String!
  portfolio: Portfolio
}

type AssetResponse {
  success: Boolean!
  message: String
}
```

### 2.3 Ventajas del Schema Explícito

1. **Auto-documentación:** El schema ES la documentación
2. **Validación automática:** GraphQL valida queries contra el schema
3. **Type safety:** Los tipos son verificables en tiempo de compilación
4. **Introspection:** El schema es consultable programáticamente
5. **Tooling:** IDEs pueden auto-completar basado en el schema

---

## 3. Pilar #2: Types (Tipos)

### 3.1 Tipos Escalares

GraphQL incluye 5 tipos escalares built-in:

```graphql
type Example {
  id: ID              # Identificador único (string serializado)
  name: String        # Cadena de texto
  age: Int            # Entero de 32 bits
  price: Float        # Número de punto flotante
  active: Boolean     # true o false
}
```

### 3.2 Object Types

Tipos personalizados que representan entidades del dominio.

```graphql
type Portfolio {
  id: ID!
  name: String!
  totalValue: Float!
}
```

### 3.3 Non-Nullable (!)

El signo `!` indica que el campo **nunca puede ser null**.

```graphql
type Portfolio {
  id: ID!          # SIEMPRE presente
  name: String!    # SIEMPRE presente
  nickname: String # PUEDE ser null
}
```

**Ejemplo:**
```json
{
  "id": "portfolio-001",        ✅ OK
  "name": "Growth Portfolio",   ✅ OK
  "nickname": null              ✅ OK (es nullable)
}

{
  "id": null,                   ❌ ERROR (debe tener valor)
  "name": "Growth Portfolio"
}
```

### 3.4 Lists (Listas)

```graphql
type Portfolio {
  assets: [Asset!]!
  #       ^^^^^^ ^^
  #       │      └─ La lista nunca es null
  #       └──────── Los elementos nunca son null
}
```

**Variaciones:**
```graphql
[Asset]      # Lista nullable con elementos nullable
[Asset]!     # Lista non-null con elementos nullable
[Asset!]     # Lista nullable con elementos non-null
[Asset!]!    # Lista non-null con elementos non-null
```

### 3.5 Enums

Tipos con valores fijos predefinidos.

```graphql
enum AssetType {
  STOCK
  CRYPTO
  ETF
  BOND
  COMMODITY
}

type Asset {
  assetType: AssetType!  # Solo puede ser uno de los 5 valores
}
```

**Ventajas:**
- Validación automática
- Auto-completado en IDEs
- Type-safe en lenguajes tipados (TypeScript, Java)

### 3.6 Input Types

Tipos especiales para argumentos de queries/mutations.

```graphql
input CreatePortfolioInput {
  name: String!
}

type Mutation {
  createPortfolio(input: CreatePortfolioInput!): PortfolioResponse!
}
```

**Diferencia vs Object Types:**
- `input` solo se usa en argumentos
- `type` solo se usa en retornos

---

## 4. Pilar #3: Queries (Lecturas)

### 4.1 Definición

Las **queries** son operaciones de **lectura** que obtienen datos del servidor.

```graphql
type Query {
  # Query sin argumentos
  myPortfolios: [Portfolio!]!
  
  # Query con argumento
  portfolio(id: ID!): Portfolio
  
  # Query con múltiples argumentos
  searchAsset(symbol: String!, type: AssetType): Asset
}
```

### 4.2 Sintaxis de una Query

**Query básica:**
```graphql
{
  myPortfolios {
    name
    totalValue
  }
}
```

**Query con argumentos:**
```graphql
{
  portfolio(id: "portfolio-001") {
    name
    totalValue
  }
}
```

**Query anidada:**
```graphql
{
  portfolio(id: "portfolio-001") {
    name
    assets {
      symbol
      currentPrice
    }
  }
}
```

### 4.3 Múltiples Queries en una Request

```graphql
{
  # Query 1
  myPortfolios {
    name
  }
  
  # Query 2
  portfolio(id: "portfolio-001") {
    totalValue
  }
  
  # Query 3
  searchAsset(symbol: "AAPL") {
    currentPrice
  }
}
```

**Resultado:**
```json
{
  "data": {
    "myPortfolios": [...],
    "portfolio": {...},
    "searchAsset": {...}
  }
}
```

---

## 5. Pilar #4: Mutations (Escrituras)

### 5.1 Definición

Las **mutations** son operaciones de **escritura** que modifican datos en el servidor.

```graphql
type Mutation {
  createPortfolio(input: CreatePortfolioInput!): PortfolioResponse!
  addAsset(input: AddAssetInput!): AssetResponse!
  removeAsset(portfolioId: ID!, assetId: ID!): AssetResponse!
}
```

### 5.2 Sintaxis de una Mutation

**Crear portfolio:**
```graphql
mutation {
  createPortfolio(input: {
    name: "Tech Growth Portfolio"
  }) {
    success
    message
    portfolio {
      id
      name
      totalValue
    }
  }
}
```

**Agregar asset:**
```graphql
mutation {
  addAsset(input: {
    portfolioId: "portfolio-001"
    symbol: "NVDA"
    assetType: STOCK
    quantity: 10
    buyPrice: 500
  }) {
    success
    message
  }
}
```

### 5.3 Response Wrappers

**Patrón recomendado:** Siempre retornar un wrapper con `success`, `message` y datos opcionales.

```graphql
type PortfolioResponse {
  success: Boolean!     # true si operación exitosa
  message: String!      # Mensaje para el usuario
  portfolio: Portfolio  # Datos solo si success=true
}
```

**Ventajas:**
- Manejo de errores consistente
- UX mejorada (mensajes claros)
- Permite retornar datos parciales

**Ejemplo de uso:**
```graphql
mutation {
  createPortfolio(input: {name: "Test"}) {
    success
    message
    portfolio {
      id
    }
  }
}
```

**Respuesta exitosa:**
```json
{
  "data": {
    "createPortfolio": {
      "success": true,
      "message": "Portfolio created successfully",
      "portfolio": {
        "id": "portfolio-abc123"
      }
    }
  }
}
```

**Respuesta con error:**
```json
{
  "data": {
    "createPortfolio": {
      "success": false,
      "message": "Portfolio name already exists",
      "portfolio": null
    }
  }
}
```

---

## 6. Pilar #5: Resolvers (Conectores)

### 6.1 Definición

Los **resolvers** son funciones que conectan las queries/mutations del schema con las fuentes de datos (base de datos, microservicios, APIs externas).

**Analogía:** Son como "controllers" en REST, pero más granulares (uno por campo si es necesario).

### 6.2 Estructura de un Resolver

```java
@QueryMapping
public List<Portfolio> myPortfolios() {
    // Lógica para obtener portfolios
    return portfolioService.findAllByUser();
}

@QueryMapping
public Portfolio portfolio(@Argument String id) {
    // Lógica para obtener portfolio por ID
    return portfolioService.findById(id);
}

@MutationMapping
public PortfolioResponse createPortfolio(@Argument CreatePortfolioInput input) {
    // Lógica para crear portfolio
    Portfolio portfolio = portfolioService.create(input);
    return new PortfolioResponse(true, "Portfolio created", portfolio);
}
```

### 6.3 Resolvers Anidados

GraphQL permite resolvers para campos individuales dentro de un tipo.

```java
// Resolver de campo: Portfolio.assets
@SchemaMapping(typeName = "Portfolio", field = "assets")
public List<Asset> assets(Portfolio portfolio) {
    return assetService.findByPortfolioId(portfolio.getId());
}

// Resolver de campo: Portfolio.performance
@SchemaMapping(typeName = "Portfolio", field = "performance")
public Performance performance(Portfolio portfolio) {
    return performanceService.calculate(portfolio);
}
```

**Ventaja:** GraphQL solo ejecuta los resolvers de los campos PEDIDOS en la query.

**Ejemplo:**
```graphql
{
  portfolio(id: "001") {
    name        # ← No resolver necesario (campo directo)
    assets {    # ← Ejecuta resolver de assets
      symbol
    }
    # performance NO se pidió, su resolver NO se ejecuta
  }
}
```

### 6.4 Resolver Chain (Cadena de Resolución)

```
Query
  └─> portfolio(id)              ← Resolver 1: PortfolioQueryResolver
       └─> assets                ← Resolver 2: AssetFieldResolver
            └─> currentPrice     ← Valor directo del objeto Asset
```

---

## 7. Consistencia Semántica

### 7.1 Estructura de Respuesta Refleja Estructura de Query

**Query:**
```graphql
{
  portfolio(id: "001") {
    name
    assets {
      symbol
    }
  }
}
```

**Respuesta (MISMA estructura):**
```json
{
  "data": {
    "portfolio": {
      "name": "Growth Portfolio",
      "assets": [
        {"symbol": "AAPL"},
        {"symbol": "GOOGL"}
      ]
    }
  }
}
```

**Ventaja:** Predecible, fácil de parsear, fácil de razonar.

### 7.2 Errores vs Datos

GraphQL separa **errores de sistema** de **errores de negocio**.

**Error de sistema:**
```json
{
  "errors": [
    {
      "message": "Field 'invalidField' doesn't exist on type 'Portfolio'",
      "locations": [{"line": 3, "column": 5}]
    }
  ]
}
```

**Error de negocio (en los datos):**
```json
{
  "data": {
    "createPortfolio": {
      "success": false,
      "message": "Name already exists",
      "portfolio": null
    }
  }
}
```

---

## 8. Ejemplo Completo: Portfolio

### 8.1 Schema
```graphql
type Query {
  myPortfolios: [Portfolio!]!
  portfolio(id: ID!): Portfolio
}

type Mutation {
  createPortfolio(input: CreatePortfolioInput!): PortfolioResponse!
}

type Portfolio {
  id: ID!
  name: String!
  totalValue: Float!
  assets: [Asset!]!
}

type Asset {
  symbol: String!
  currentPrice: Float!
}

input CreatePortfolioInput {
  name: String!
}

type PortfolioResponse {
  success: Boolean!
  message: String!
  portfolio: Portfolio
}
```

### 8.2 Query de Ejemplo
```graphql
{
  portfolio(id: "portfolio-001") {
    name
    totalValue
    assets {
      symbol
      currentPrice
    }
  }
}
```

### 8.3 Mutation de Ejemplo
```graphql
mutation {
  createPortfolio(input: {
    name: "New Portfolio"
  }) {
    success
    message
    portfolio {
      id
      name
    }
  }
}
```

### 8.4 Resolvers (Java/Spring)
```java
@Controller
public class PortfolioResolvers {
    
    @Autowired
    private PortfolioService portfolioService;
    
    @QueryMapping
    public List<Portfolio> myPortfolios() {
        return portfolioService.findAll();
    }
    
    @QueryMapping
    public Portfolio portfolio(@Argument String id) {
        return portfolioService.findById(id);
    }
    
    @MutationMapping
    public PortfolioResponse createPortfolio(@Argument CreatePortfolioInput input) {
        Portfolio portfolio = portfolioService.create(input.getName());
        return new PortfolioResponse(true, "Created", portfolio);
    }
    
    @SchemaMapping(typeName = "Portfolio", field = "assets")
    public List<Asset> assets(Portfolio portfolio) {
        return portfolioService.getAssets(portfolio.getId());
    }
}
```

---

## 9. Resumen de Sección 1.2

### Los 5 Pilares:

1. **Schema:** Contrato explícito y ejecutable
2. **Types:** Portfolio, Asset, Performance, etc. (dominio)
3. **Queries:** Operaciones de lectura (`myPortfolios`, `portfolio`)
4. **Mutations:** Operaciones de escritura (`createPortfolio`, `addAsset`)
5. **Resolvers:** Lógica que conecta queries/mutations con datos

### Conceptos clave:

- ✅ El schema ES la documentación
- ✅ Types definen la forma de los datos
- ✅ Queries obtienen, Mutations modifican
- ✅ Resolvers son la "lógica de conexión"
- ✅ La respuesta refleja la estructura de la query

---

# Sección 1.3 - Consultas anidadas y uso de variables

**Duración:** 30 minutos

## 🎯 Objetivo

Profundizar en la capacidad de GraphQL para realizar consultas complejas mediante anidación de entidades relacionadas. Introducir el uso de variables en las consultas para mejorar la reusabilidad y evitar inyecciones inseguras.

---

## 1. Consultas Anidadas

### 1.1 El Problema con REST

**Escenario:** Obtener un portfolio con sus assets y el mejor performer.

**REST (3 llamadas):**
```http
1. GET /api/portfolios/portfolio-001
   → Retorna: portfolio básico

2. GET /api/portfolios/portfolio-001/assets
   → Retorna: lista de assets

3. GET /api/portfolios/portfolio-001/performance
   → Retorna: performance con bestPerformer
```

**GraphQL (1 llamada):**
```graphql
{
  portfolio(id: "portfolio-001") {
    name
    assets {
      symbol
      currentPrice
    }
    performance {
      totalReturn
      bestPerformer {
        symbol
        profitLossPercent
      }
    }
  }
}
```

### 1.2 Anidación de Nivel 1: Portfolio → Assets

**Query:**
```graphql
{
  portfolio(id: "portfolio-001") {
    name
    totalValue
    assets {          # ← Nivel 1 de anidación
      symbol
      currentPrice
      quantity
    }
  }
}
```

**Respuesta:**
```json
{
  "data": {
    "portfolio": {
      "name": "Growth Portfolio",
      "totalValue": 59013.75,
      "assets": [
        {
          "symbol": "AAPL",
          "currentPrice": 185.5,
          "quantity": 10
        },
        {
          "symbol": "GOOGL",
          "currentPrice": 142.3,
          "quantity": 5
        }
      ]
    }
  }
}
```

### 1.3 Anidación de Nivel 2: Portfolio → Performance → BestPerformer

**Query:**
```graphql
{
  portfolio(id: "portfolio-001") {
    name
    performance {               # ← Nivel 1
      totalReturn
      yearReturn
      bestPerformer {           # ← Nivel 2
        symbol
        profitLossPercent
        currentPrice
      }
    }
  }
}
```

**Respuesta:**
```json
{
  "data": {
    "portfolio": {
      "name": "Growth Portfolio",
      "performance": {
        "totalReturn": 22.31,
        "yearReturn": 17.85,
        "bestPerformer": {
          "symbol": "BTC",
          "profitLossPercent": 48.88,
          "currentPrice": 67500
        }
      }
    }
  }
}
```

### 1.4 Anidación de Nivel 3: Relaciones Múltiples

**Query:**
```graphql
{
  portfolio(id: "portfolio-001") {
    name
    owner {                    # ← Nivel 1
      name
      preferences {            # ← Nivel 2
        riskTolerance
        favoriteAssets {       # ← Nivel 3
          symbol
          name
        }
      }
    }
    assets {                   # ← Nivel 1 paralelo
      symbol
      transactions {           # ← Nivel 2 paralelo
        date
        type
        quantity
      }
    }
  }
}
```

**Ventaja:** Una sola query obtiene todo el grafo de relaciones necesarias.

---

## 2. Variables en Queries

### 2.1 El Problema: Hardcoded Values

**Query sin variables (MALA PRÁCTICA):**
```graphql
{
  portfolio(id: "portfolio-001") {
    name
  }
}
```

**Problemas:**
- ❌ No reusable (ID hardcoded)
- ❌ Cada ID requiere una query diferente
- ❌ Riesgo de injection si se concatena string

### 2.2 Solución: Variables Tipadas

**Query con variable (BUENA PRÁCTICA):**
```graphql
query GetPortfolio($id: ID!) {
  portfolio(id: $id) {
    name
    totalValue
  }
}
```

**Variables (JSON separado):**
```json
{
  "id": "portfolio-001"
}
```

**Beneficios:**
- ✅ Reusable (cambias solo las variables)
- ✅ Tipado fuerte (`$id: ID!` valida tipo)
- ✅ Seguro (GraphQL escapa automáticamente)
- ✅ Cacheable (query es siempre la misma)

### 2.3 Sintaxis de Variables

**Estructura:**
```graphql
query NombreOperacion($variable: Tipo!) {
  campo(argumento: $variable) {
    ...
  }
}
```

**Elementos:**
- `query`: Tipo de operación (también puede ser `mutation`)
- `NombreOperacion`: Nombre descriptivo (opcional pero recomendado)
- `$variable`: Nombre de la variable (debe empezar con `$`)
- `Tipo!`: Tipo de la variable (`!` = obligatorio)

### 2.4 Variables Múltiples

**Query con múltiples variables:**
```graphql
query SearchAssets(
  $portfolioId: ID!,
  $minValue: Float,
  $assetType: AssetType
) {
  assets(
    portfolioId: $portfolioId,
    filter: {
      minValue: $minValue,
      assetType: $assetType
    }
  ) {
    edges {
      node {
        symbol
        totalValue
      }
    }
  }
}
```

**Variables:**
```json
{
  "portfolioId": "portfolio-001",
  "minValue": 5000,
  "assetType": "STOCK"
}
```

### 2.5 Variables con Defaults

```graphql
query GetPortfolios(
  $limit: Int = 10,           # ← Default: 10
  $sortBy: String = "name"    # ← Default: "name"
) {
  myPortfolios(limit: $limit, sortBy: $sortBy) {
    name
  }
}
```

**Uso sin variables:**
```json
{}  // Usa defaults: limit=10, sortBy="name"
```

**Uso con variables parciales:**
```json
{
  "limit": 5  // Usa limit=5, sortBy="name" (default)
}
```

---

## 3. Validación Automática de Variables

### 3.1 Validación de Tipo

GraphQL valida que las variables coincidan con el tipo declarado.

**Query:**
```graphql
query GetPortfolio($id: ID!) {
  portfolio(id: $id) { name }
}
```

**Variables incorrectas:**
```json
{
  "id": 123  // ❌ ERROR: ID debe ser String
}
```

**Error:**
```json
{
  "errors": [
    {
      "message": "Variable '$id' has invalid value: Expected type 'ID' but got 'Int'"
    }
  ]
}
```

### 3.2 Validación de Obligatoriedad

**Query con variable obligatoria:**
```graphql
query GetPortfolio($id: ID!) {  # ← ! = obligatorio
  portfolio(id: $id) { name }
}
```

**Variables faltantes:**
```json
{}  // ❌ ERROR: $id es obligatorio
```

**Error:**
```json
{
  "errors": [
    {
      "message": "Variable '$id' of required type 'ID!' was not provided"
    }
  ]
}
```

### 3.3 Validación de Enums

**Query:**
```graphql
query SearchByType($type: AssetType!) {
  searchAsset(type: $type) { symbol }
}
```

**Variables incorrectas:**
```json
{
  "type": "INVALID_TYPE"  // ❌ ERROR: No está en el enum
}
```

**Error:**
```json
{
  "errors": [
    {
      "message": "Variable '$type' has invalid value: Expected type 'AssetType' but got 'INVALID_TYPE'. Valid values: STOCK, CRYPTO, ETF, BOND, COMMODITY"
    }
  ]
}
```

---

## 4. Argumentos Dinámicos y Consultas Parametrizadas

### 4.1 Reusabilidad

**Escenario:** App móvil necesita obtener portfolios de diferentes usuarios.

**SIN variables (requiere múltiples queries):**
```graphql
# Query para usuario 1
{ portfolio(id: "portfolio-001") { name } }

# Query para usuario 2
{ portfolio(id: "portfolio-002") { name } }

# Query para usuario 3
{ portfolio(id: "portfolio-003") { name } }
```

**CON variables (1 query reutilizable):**
```graphql
query GetPortfolio($id: ID!) {
  portfolio(id: $id) { name }
}
```

**Uso:**
```javascript
// Frontend code
const query = GET_PORTFOLIO_QUERY; // Misma query siempre

// Usuario 1
fetchGraphQL(query, { id: "portfolio-001" });

// Usuario 2
fetchGraphQL(query, { id: "portfolio-002" });

// Usuario 3
fetchGraphQL(query, { id: "portfolio-003" });
```

### 4.2 Seguridad: Anti-Injection

**INSEGURO (concatenación de strings):**
```javascript
// ❌ NUNCA HACER ESTO
const userId = getUserInput();
const query = `
  {
    portfolio(id: "${userId}") { name }
  }
`;
// Riesgo de injection
```

**SEGURO (variables):**
```javascript
// ✅ CORRECTO
const query = `
  query GetPortfolio($id: ID!) {
    portfolio(id: $id) { name }
  }
`;
const variables = { id: getUserInput() };

fetchGraphQL(query, variables);
// GraphQL escapa automáticamente
```

---

## 5. Ejemplos Prácticos

### Ejemplo 1: Query Anidada Completa

**Necesidad:** Obtener portfolio con todos sus datos relacionados.

**Query:**
```graphql
query GetCompletePortfolio($id: ID!) {
  portfolio(id: $id) {
    # Nivel 0: Portfolio básico
    id
    name
    totalValue
    createdAt
    
    # Nivel 1: Assets
    assets {
      id
      symbol
      name
      assetType
      quantity
      currentPrice
      totalValue
      profitLossPercent
    }
    
    # Nivel 1: Performance
    performance {
      totalReturn
      yearReturn
      monthReturn
      
      # Nivel 2: Best/Worst Performers
      bestPerformer {
        symbol
        profitLossPercent
      }
      worstPerformer {
        symbol
        profitLossPercent
      }
    }
  }
}
```

**Variables:**
```json
{
  "id": "portfolio-001"
}
```

---

### Ejemplo 2: Múltiples Relaciones Paralelas

**Query:**
```graphql
query GetUserData($userId: ID!) {
  user(id: $userId) {
    name
    email
    
    # Relación 1: Portfolios
    portfolios {
      name
      totalValue
    }
    
    # Relación 2: Transactions
    transactions(limit: 10) {
      date
      type
      amount
    }
    
    # Relación 3: Preferences
    preferences {
      riskTolerance
      notifications
    }
  }
}
```

---

### Ejemplo 3: Variables con Input Objects

**Schema:**
```graphql
input AssetFilterInput {
  assetType: AssetType
  minValue: Float
  maxValue: Float
}

type Query {
  assets(
    portfolioId: ID!,
    filter: AssetFilterInput
  ): AssetConnection!
}
```

**Query:**
```graphql
query FilterAssets(
  $portfolioId: ID!,
  $filter: AssetFilterInput
) {
  assets(portfolioId: $portfolioId, filter: $filter) {
    totalCount
    edges {
      node {
        symbol
        totalValue
      }
    }
  }
}
```

**Variables:**
```json
{
  "portfolioId": "portfolio-001",
  "filter": {
    "assetType": "STOCK",
    "minValue": 5000,
    "maxValue": 50000
  }
}
```

---

## 6. Contextos de Múltiples Consumidores

### 6.1 Escenario: Mobile, Web y Tablet

**Mismo backend, diferentes necesidades:**

**Mobile (conexión lenta):**
```graphql
query GetPortfolioMobile($id: ID!) {
  portfolio(id: $id) {
    name
    totalValue  # Solo lo esencial
  }
}
```

**Web (más detalles):**
```graphql
query GetPortfolioWeb($id: ID!) {
  portfolio(id: $id) {
    name
    totalValue
    createdAt
    assets {
      symbol
      currentPrice
    }
  }
}
```

**Tablet (vista completa):**
```graphql
query GetPortfolioTablet($id: ID!) {
  portfolio(id: $id) {
    name
    totalValue
    createdAt
    assets {
      symbol
      name
      currentPrice
      quantity
      profitLossPercent
    }
    performance {
      totalReturn
      yearReturn
    }
  }
}
```

**Ventaja:** UN backend sirve a TRES clientes con necesidades diferentes.

---

## 7. Resumen de Sección 1.3

### Anidación de consultas:

- ✅ Obtener relaciones en UNA query
- ✅ Niveles múltiples: Portfolio → Performance → BestPerformer
- ✅ Relaciones paralelas en una sola llamada
- ✅ Reduce latencia (1 request vs múltiples)

### Variables:

- ✅ **Reusabilidad:** Misma query, diferentes valores
- ✅ **Tipado fuerte:** `$id: ID!` valida automáticamente
- ✅ **Seguridad:** Anti-injection built-in
- ✅ **Flexibilidad:** Múltiples variables, defaults opcionales

### Conceptos clave:

- 🔹 Variables mejoran reusabilidad y evitan inyecciones
- 🔹 GraphQL valida tipos de variables automáticamente
- 🔹 Anidación permite obtener grafos completos
- 🔹 Un mismo schema sirve a múltiples clientes con necesidades diferentes

---

# Sección 1.4 - Filtros orden y paginación

**Duración:** 30 minutos

## 🎯 Objetivo

Abordar cómo GraphQL permite enriquecer las consultas mediante argumentos que definen criterios de filtrado, ordenamiento y paginación. Revisar ejemplos de `filter`, `orderBy`, `limit` y `offset`, así como el uso del modelo **cursor-based pagination** para aplicaciones que manejan grandes volúmenes de datos.

---

## 1. El Problema: Datasets Grandes

### 1.1 Escenario Real

**NeoBank tiene:**
- 1 millón de usuarios
- Cada usuario tiene 1-100 portfolios
- Cada portfolio tiene 1-1000 assets

**Problema:** ¿Cómo obtener "los 10 assets más rentables de tipo STOCK con valor > $5000"?

**REST tradicional:**
```http
GET /api/assets?portfolioId=001&type=STOCK&minValue=5000&sort=profitLoss&order=desc&limit=10
```

**Problemas:**
- ❌ URL compleja y frágil
- ❌ Cada combinación requiere endpoint específico
- ❌ Paginación inconsistente (offset-based tiene problemas)

---

## 2. Filtrado en GraphQL

### 2.1 Definición de Filtros en Schema

```graphql
input AssetFilterInput {
  assetType: AssetType       # Filtrar por tipo
  minValue: Float            # Valor mínimo
  maxValue: Float            # Valor máximo
  symbols: [String!]         # Lista de símbolos específicos
}

type Query {
  assets(
    portfolioId: ID!,
    filter: AssetFilterInput   # ← Argumento de filtro
  ): AssetConnection!
}
```

### 2.2 Query con Filtro Simple

**Filtrar solo STOCKS:**
```graphql
{
  assets(
    portfolioId: "portfolio-001",
    filter: {
      assetType: STOCK
    }
  ) {
    totalCount
    edges {
      node {
        symbol
        assetType
      }
    }
  }
}
```

**Respuesta:**
```json
{
  "data": {
    "assets": {
      "totalCount": 2,
      "edges": [
        { "node": { "symbol": "AAPL", "assetType": "STOCK" } },
        { "node": { "symbol": "GOOGL", "assetType": "STOCK" } }
      ]
    }
  }
}
```

### 2.3 Filtros Múltiples

**Filtrar STOCKS con valor > $5000:**
```graphql
{
  assets(
    portfolioId: "portfolio-001",
    filter: {
      assetType: STOCK,
      minValue: 5000
    }
  ) {
    totalCount
    edges {
      node {
        symbol
        totalValue
      }
    }
  }
}
```

### 2.4 Filtros con Rangos

**Assets entre $5000 y $20000:**
```graphql
{
  assets(
    portfolioId: "portfolio-001",
    filter: {
      minValue: 5000,
      maxValue: 20000
    }
  ) {
    totalCount
    edges {
      node {
        symbol
        totalValue
      }
    }
  }
}
```

### 2.5 Filtros con Listas

**Solo AAPL, GOOGL y MSFT:**
```graphql
{
  assets(
    portfolioId: "portfolio-001",
    filter: {
      symbols: ["AAPL", "GOOGL", "MSFT"]
    }
  ) {
    totalCount
    edges {
      node {
        symbol
      }
    }
  }
}
```

---

## 3. Ordenamiento en GraphQL

### 3.1 Definición de Ordenamiento en Schema

```graphql
enum AssetSortField {
  SYMBOL
  CURRENT_PRICE
  TOTAL_VALUE
  PROFIT_LOSS_PERCENT
  QUANTITY
}

enum SortDirection {
  ASC
  DESC
}

input AssetSortInput {
  field: AssetSortField!
  direction: SortDirection!
}

type Query {
  assets(
    portfolioId: ID!,
    filter: AssetFilterInput,
    sort: AssetSortInput        # ← Argumento de ordenamiento
  ): AssetConnection!
}
```

### 3.2 Query con Ordenamiento

**Ordenar por valor total (mayor primero):**
```graphql
{
  assets(
    portfolioId: "portfolio-001",
    sort: {
      field: TOTAL_VALUE,
      direction: DESC
    }
  ) {
    edges {
      node {
        symbol
        totalValue
      }
    }
  }
}
```

**Respuesta:**
```json
{
  "data": {
    "assets": {
      "edges": [
        { "node": { "symbol": "BTC", "totalValue": 67500 } },
        { "node": { "symbol": "GOOGL", "totalValue": 7115 } },
        { "node": { "symbol": "VOO", "totalValue": 5888 } },
        { "node": { "symbol": "AAPL", "totalValue": 1855 } }
      ]
    }
  }
}
```

### 3.3 Ordenar por Ganancia/Pérdida

**Mejor performance primero:**
```graphql
{
  assets(
    portfolioId: "portfolio-001",
    sort: {
      field: PROFIT_LOSS_PERCENT,
      direction: DESC
    }
  ) {
    edges {
      node {
        symbol
        profitLossPercent
      }
    }
  }
}
```

---

## 4. Paginación en GraphQL

### 4.1 Problema con Offset-Based Pagination

**REST tradicional:**
```http
GET /api/assets?limit=10&offset=0   # Página 1
GET /api/assets?limit=10&offset=10  # Página 2
```

**Problemas:**
- ❌ **Datos duplicados:** Si se insertan items entre páginas
- ❌ **Datos faltantes:** Si se borran items entre páginas
- ❌ **Ineficiente en DB:** OFFSET requiere escanear todos los rows previos

**Ejemplo del problema:**
```
Página 1 (offset=0, limit=10): Items 1-10
[Se inserta nuevo item al principio]
Página 2 (offset=10, limit=10): Items 11-20
→ ¡El item #10 aparece dos veces!
```

### 4.2 Solución: Cursor-Based Pagination

GraphQL recomienda **cursor-based pagination** (paginación basada en cursores).

**Concepto:**
- Cada item tiene un **cursor** único (ej: ID codificado en Base64)
- Pides "N items DESPUÉS de este cursor"
- Garantiza consistencia incluso si los datos cambian

### 4.3 Relay Cursor Connections Specification

GraphQL sigue el estándar de **Relay** para paginación:

```graphql
type AssetConnection {
  totalCount: Int!               # Total de items
  edges: [AssetEdge!]!           # Lista de edges
  pageInfo: PageInfo!            # Información de paginación
}

type AssetEdge {
  node: Asset!                   # El asset en sí
  cursor: String!                # Cursor único de este asset
}

type PageInfo {
  hasNextPage: Boolean!          # ¿Hay más páginas?
  hasPreviousPage: Boolean!      # ¿Hay páginas anteriores?
  startCursor: String            # Cursor del primer item
  endCursor: String              # Cursor del último item
}
```

### 4.4 Query de Paginación

**Primera página (primeros 10 items):**
```graphql
{
  assets(
    portfolioId: "portfolio-001",
    pagination: {
      first: 10
    }
  ) {
    totalCount
    pageInfo {
      hasNextPage
      endCursor
    }
    edges {
      cursor
      node {
        symbol
        totalValue
      }
    }
  }
}
```

**Respuesta:**
```json
{
  "data": {
    "assets": {
      "totalCount": 42,
      "pageInfo": {
        "hasNextPage": true,
        "endCursor": "YXNzZXQtMDEw"
      },
      "edges": [
        {
          "cursor": "YXNzZXQtMDAx",
          "node": { "symbol": "AAPL", "totalValue": 1855 }
        },
        // ... 9 more
      ]
    }
  }
}
```

**Segunda página (usando cursor de la primera):**
```graphql
{
  assets(
    portfolioId: "portfolio-001",
    pagination: {
      first: 10,
      after: "YXNzZXQtMDEw"  # ← Cursor del último item
    }
  ) {
    pageInfo {
      hasNextPage
      endCursor
    }
    edges {
      cursor
      node {
        symbol
      }
    }
  }
}
```

### 4.5 Ventajas de Cursor-Based Pagination

✅ **Consistente:** No se duplican/pierden items  
✅ **Performante:** No requiere OFFSET costoso  
✅ **Escalable:** Funciona con datasets de millones de registros  
✅ **Bi-direccional:** Puedes paginar hacia adelante (`after`) o atrás (`before`)  

---

## 5. Combinando Filtro + Orden + Paginación

### 5.1 Query Compleja

**Necesidad:** Los 10 STOCKS más rentables con valor > $5000.

```graphql
{
  assets(
    portfolioId: "portfolio-001",
    filter: {
      assetType: STOCK,
      minValue: 5000
    },
    sort: {
      field: PROFIT_LOSS_PERCENT,
      direction: DESC
    },
    pagination: {
      first: 10
    }
  ) {
    totalCount
    pageInfo {
      hasNextPage
    }
    edges {
      node {
        symbol
        totalValue
        profitLossPercent
      }
    }
  }
}
```

**Respuesta:**
```json
{
  "data": {
    "assets": {
      "totalCount": 2,
      "pageInfo": {
        "hasNextPage": false
      },
      "edges": [
        {
          "node": {
            "symbol": "GOOGL",
            "totalValue": 7115,
            "profitLossPercent": 23.67
          }
        },
        {
          "node": {
            "symbol": "VOO",
            "totalValue": 5888,
            "profitLossPercent": 11.31
          }
        }
      ]
    }
  }
}
```

---

## 6. Límites y Validaciones del Backend

### 6.1 Prevención de Queries Costosas

**Problema:** Cliente pide 1 millón de items.

```graphql
{
  assets(pagination: { first: 1000000 }) {  # ❌ Peligroso
    edges { node { symbol } }
  }
}
```

**Solución:** Backend impone límites.

```java
@QueryMapping
public AssetConnection assets(
    @Argument String portfolioId,
    @Argument PaginationInput pagination
) {
    // Validar límite máximo
    int limit = pagination.getFirst();
    if (limit > 100) {
        throw new GraphQLException("Maximum limit is 100");
    }
    
    // Continuar con la query...
}
```

### 6.2 Límites Recomendados

```graphql
input PaginationInput {
  first: Int      # Máximo recomendado: 100
  after: String
}
```

**Estrategia:**
- Mobile: `first: 10` (pantalla pequeña)
- Web: `first: 25` (balance)
- Admin: `first: 50` (más contexto)
- **Nunca más de 100 items por página**

---

## 7. Manejo Eficiente de Resolvers

### 7.1 Resolver con Filtrado

```java
@QueryMapping
public AssetConnection assets(
    @Argument String portfolioId,
    @Argument AssetFilterInput filter,
    @Argument AssetSortInput sort,
    @Argument PaginationInput pagination
) {
    // 1. Obtener assets del portfolio
    List<Asset> assets = assetRepository.findByPortfolioId(portfolioId);
    
    // 2. Aplicar filtros
    if (filter != null) {
        if (filter.getAssetType() != null) {
            assets = assets.stream()
                .filter(a -> a.getAssetType() == filter.getAssetType())
                .collect(Collectors.toList());
        }
        
        if (filter.getMinValue() != null) {
            assets = assets.stream()
                .filter(a -> a.getTotalValue() >= filter.getMinValue())
                .collect(Collectors.toList());
        }
    }
    
    // 3. Aplicar ordenamiento
    if (sort != null) {
        Comparator<Asset> comparator = getComparator(sort.getField());
        if (sort.getDirection() == SortDirection.DESC) {
            comparator = comparator.reversed();
        }
        assets.sort(comparator);
    }
    
    // 4. Aplicar paginación
    int totalCount = assets.size();
    int limit = pagination.getFirst();
    List<Asset> page = assets.stream()
        .limit(limit)
        .collect(Collectors.toList());
    
    // 5. Construir connection
    return new AssetConnection(totalCount, page, hasNextPage);
}
```

### 7.2 Optimización con DB Queries

**MEJOR PRÁCTICA:** Delegar a la base de datos.

```java
@QueryMapping
public AssetConnection assets(
    @Argument String portfolioId,
    @Argument AssetFilterInput filter,
    @Argument AssetSortInput sort,
    @Argument PaginationInput pagination
) {
    // Construir query dinámica en DB
    CriteriaBuilder cb = entityManager.getCriteriaBuilder();
    CriteriaQuery<Asset> query = cb.createQuery(Asset.class);
    Root<Asset> root = query.from(Asset.class);
    
    // WHERE portfolio_id = ?
    Predicate predicate = cb.equal(root.get("portfolioId"), portfolioId);
    
    // AND asset_type = ? (si filter.assetType presente)
    if (filter != null && filter.getAssetType() != null) {
        predicate = cb.and(predicate, 
            cb.equal(root.get("assetType"), filter.getAssetType()));
    }
    
    // ORDER BY total_value DESC
    if (sort != null) {
        Order order = sort.getDirection() == SortDirection.ASC
            ? cb.asc(root.get(sort.getField()))
            : cb.desc(root.get(sort.getField()));
        query.orderBy(order);
    }
    
    query.where(predicate);
    
    // LIMIT 10
    List<Asset> results = entityManager.createQuery(query)
        .setMaxResults(pagination.getFirst())
        .getResultList();
    
    return new AssetConnection(results);
}
```

---

## 8. Resumen de Sección 1.4

### Filtrado:

- ✅ `filter: { assetType: STOCK, minValue: 5000 }`
- ✅ Múltiples criterios combinables
- ✅ Rangos, listas, valores exactos

### Ordenamiento:

- ✅ `sort: { field: TOTAL_VALUE, direction: DESC }`
- ✅ Ordenar por cualquier campo del schema
- ✅ ASC o DESC

### Paginación:

- ✅ **Cursor-based** mejor que offset-based
- ✅ `first: 10, after: "cursor"`
- ✅ `PageInfo` con `hasNextPage`, `endCursor`
- ✅ Consistente incluso si datos cambian

### Límites del backend:

- ✅ Máximo 100 items por página
- ✅ Validación automática en resolvers
- ✅ Prevención de queries costosas

### Combinación:

- ✅ Filtro + Orden + Paginación en UNA query
- ✅ Backend optimiza con DB queries
- ✅ Flexibilidad sin múltiples endpoints

---

# Sección 1.5 - Tipado nullabilidad y seguridad básica

**Duración:** 30 minutos

## 🎯 Objetivo

Introducir el concepto de **tipado fuerte** que caracteriza a GraphQL. Analizar cómo la validación de tipos evita solicitudes inválidas antes de que lleguen al backend, reduciendo la carga operativa y los errores de integración. Explicar los modificadores de **nullabilidad** (`!`) y su impacto en la robustez del contrato. Presentar nociones básicas de seguridad: cómo propagar credenciales mediante headers (JWT, API Keys) y cómo restringir el acceso a campos o resolvers a través del contexto del servidor.

---

## 1. Tipado Fuerte en GraphQL

### 1.1 ¿Qué es Tipado Fuerte?

**Definición:** Cada campo, argumento y variable tiene un **tipo explícito** que GraphQL valida ANTES de ejecutar la query.

**Comparación:**

**REST (sin tipado):**
```http
GET /api/portfolio?id=abc123&value=not-a-number

→ Servidor recibe request
→ Procesa hasta fallar en conversión
→ Error 500 o datos incorrectos
```

**GraphQL (tipado fuerte):**
```graphql
query GetPortfolio($id: ID!, $minValue: Float!) {
  portfolio(id: $id, minValue: $minValue) {
    name
  }
}

Variables: { "id": "abc123", "minValue": "not-a-number" }

→ GraphQL RECHAZA antes de ejecutar
→ Error claro: "Expected Float, got String"
```

### 1.2 Tipos Escalares

GraphQL valida automáticamente los 5 tipos escalares:

```graphql
type Portfolio {
  id: ID              # String único
  name: String        # Cadena de texto
  assetCount: Int     # Entero 32-bit
  totalValue: Float   # Número decimal
  active: Boolean     # true/false
}
```

**Validaciones automáticas:**

| Tipo | Válido | Inválido |
|------|--------|----------|
| `ID` | `"123"`, `"abc"` | `null` (si es `ID!`) |
| `String` | `"Hello"`, `""` | `123` (número sin comillas) |
| `Int` | `42`, `-5` | `3.14` (decimal), `"42"` (string) |
| `Float` | `3.14`, `42` | `"3.14"` (string) |
| `Boolean` | `true`, `false` | `"true"` (string), `1` (número) |

### 1.3 Ejemplo de Validación Automática

**Query:**
```graphql
query GetPortfolio($id: ID!, $minValue: Float!) {
  portfolio(id: $id, minValue: $minValue) {
    name
  }
}
```

**Variables INCORRECTAS:**
```json
{
  "id": 123,                    // ❌ ID debe ser String
  "minValue": "not-a-number"    // ❌ Float debe ser número
}
```

**Error (ANTES de ejecutar):**
```json
{
  "errors": [
    {
      "message": "Variable '$id' has invalid value: Expected type 'ID' but got 'Int'",
      "extensions": {
        "classification": "ValidationError"
      }
    },
    {
      "message": "Variable '$minValue' has invalid value: Expected type 'Float' but got 'String'",
      "extensions": {
        "classification": "ValidationError"
      }
    }
  ]
}
```

**Ventaja:** El error se detecta ANTES de tocar la base de datos o ejecutar lógica de negocio.

---

## 2. Nullabilidad y Modificador `!`

### 2.1 Nullable vs Non-Nullable

**Sin `!` (nullable):**
```graphql
type Portfolio {
  nickname: String    # Puede ser null
}
```

**Con `!` (non-nullable):**
```graphql
type Portfolio {
  name: String!       # NUNCA puede ser null
}
```

### 2.2 Garantías del Sistema

**Campo non-nullable (`!`):**
- ✅ GraphQL **garantiza** que NUNCA retornará `null`
- ✅ Si el resolver retorna `null`, GraphQL lanza ERROR
- ✅ Cliente puede confiar que el campo siempre tiene valor

**Ejemplo:**
```graphql
type Portfolio {
  id: ID!
  name: String!
  nickname: String    # Opcional
}
```

**Respuesta VÁLIDA:**
```json
{
  "data": {
    "portfolio": {
      "id": "portfolio-001",
      "name": "Growth Portfolio",
      "nickname": null          // ✅ OK (no tiene !)
    }
  }
}
```

**Respuesta INVÁLIDA (causaría error):**
```json
{
  "data": {
    "portfolio": {
      "id": "portfolio-001",
      "name": null              // ❌ ERROR: name! no puede ser null
    }
  }
}
```

### 2.3 Listas y Nullabilidad

**Variaciones de listas:**

```graphql
type Portfolio {
  # 1. Lista nullable, elementos nullable
  tags: [String]
  # ✅ null | ✅ [] | ✅ ["tag1", null]
  
  # 2. Lista non-null, elementos nullable
  categories: [String]!
  # ❌ null | ✅ [] | ✅ ["cat1", null]
  
  # 3. Lista nullable, elementos non-null
  labels: [String!]
  # ✅ null | ✅ [] | ❌ ["label1", null]
  
  # 4. Lista non-null, elementos non-null
  assets: [Asset!]!
  # ❌ null | ✅ [] | ❌ [asset1, null]
}
```

**Tabla de verdad:**

| Declaración | `null` | `[]` | `[null]` | `[value]` |
|-------------|--------|------|----------|-----------|
| `[String]` | ✅ | ✅ | ✅ | ✅ |
| `[String]!` | ❌ | ✅ | ✅ | ✅ |
| `[String!]` | ✅ | ✅ | ❌ | ✅ |
| `[String!]!` | ❌ | ✅ | ❌ | ✅ |

### 2.4 Impacto en Robustez del Contrato

**Ventajas de usar `!`:**
- ✅ Elimina `null` checks en cliente
- ✅ TypeScript/Swift/Kotlin generan tipos non-nullable
- ✅ Menos bugs (NullPointerException imposibles)

**Ejemplo TypeScript:**
```typescript
// Sin !
type Portfolio = {
  name: string | null  // Cliente debe validar
}

if (portfolio.name !== null) {
  console.log(portfolio.name.toUpperCase());
}

// Con !
type Portfolio = {
  name: string  // Cliente confía que existe
}

console.log(portfolio.name.toUpperCase());  // Safe!
```

---

## 3. Enums y Validación

### 3.1 Definición de Enums

```graphql
enum AssetType {
  STOCK
  CRYPTO
  ETF
  BOND
  COMMODITY
}

type Asset {
  assetType: AssetType!
}
```

### 3.2 Validación Automática

**Query con enum inválido:**
```graphql
{
  searchAsset(type: INVALID_TYPE) {  # ❌ No existe en el enum
    symbol
  }
}
```

**Error:**
```json
{
  "errors": [
    {
      "message": "Argument 'type' has invalid value: Expected type 'AssetType', found 'INVALID_TYPE'. Valid values: STOCK, CRYPTO, ETF, BOND, COMMODITY"
    }
  ]
}
```

### 3.3 Ventajas de Enums

- ✅ Valores limitados y validados
- ✅ Auto-completado en GraphiQL
- ✅ Type-safe en código (TypeScript, Java)
- ✅ Documentación auto-generada

---

## 4. Introspection: Auto-Documentación

### 4.1 ¿Qué es Introspection?

**Introspection** permite consultar el schema mismo mediante GraphQL.

**Query de introspection:**
```graphql
{
  __schema {
    types {
      name
      kind
    }
  }
}
```

**Respuesta:**
```json
{
  "data": {
    "__schema": {
      "types": [
        { "name": "Portfolio", "kind": "OBJECT" },
        { "name": "Asset", "kind": "OBJECT" },
        { "name": "AssetType", "kind": "ENUM" },
        { "name": "String", "kind": "SCALAR" },
        ...
      ]
    }
  }
}
```

### 4.2 Consultar Campos de un Tipo

```graphql
{
  __type(name: "Portfolio") {
    name
    fields {
      name
      type {
        name
        kind
      }
    }
  }
}
```

**Respuesta:**
```json
{
  "data": {
    "__type": {
      "name": "Portfolio",
      "fields": [
        {
          "name": "id",
          "type": { "name": "ID", "kind": "SCALAR" }
        },
        {
          "name": "name",
          "type": { "name": "String", "kind": "SCALAR" }
        },
        {
          "name": "assets",
          "type": { "name": "Asset", "kind": "OBJECT" }
        }
      ]
    }
  }
}
```

### 4.3 Herramientas que Usan Introspection

- **GraphiQL:** Auto-completado y docs
- **Apollo Client:** Code generation
- **Postman:** Importar schema automáticamente
- **GraphQL Code Generator:** Genera TypeScript types

### 4.4 Desactivar Introspection en Producción

**Riesgo:** Introspection expone estructura completa del schema.

**Solución:** Desactivar en producción.

```java
@Configuration
public class GraphQLConfig {
    
    @Bean
    public GraphQlSource graphQlSource(Schema schema) {
        return GraphQlSource.schemaResourceBuilder()
            .schemaResources(schema)
            .configureRuntimeWiring(builder -> {
                // Desactivar introspection
                builder.introspectionEnabled(false);
            })
            .build();
    }
}
```

---

## 5. Seguridad Básica

### 5.1 Autenticación con JWT

**Flujo:**
```
Cliente                          Servidor GraphQL
  │                                    │
  │── POST /graphql ───────────────────▶│
  │   Header: Authorization: Bearer JWT │
  │                                    │
  │                    ┌───────────────┤
  │                    │ Validar JWT   │
  │                    │ Extraer userId│
  │                    └───────────────┤
  │                                    │
  │◀────── Response ───────────────────│
```

**Implementación (Spring Boot):**

```java
@Component
public class GraphQLSecurityInterceptor implements WebGraphQlInterceptor {
    
    @Autowired
    private JwtTokenProvider jwtProvider;
    
    @Override
    public Mono<WebGraphQlResponse> intercept(
        WebGraphQlRequest request, 
        Chain chain
    ) {
        // 1. Extraer JWT del header
        String token = extractToken(request);
        
        // 2. Validar JWT
        if (token == null || !jwtProvider.validateToken(token)) {
            throw new GraphQLException("Unauthorized");
        }
        
        // 3. Extraer userId del token
        String userId = jwtProvider.getUserId(token);
        
        // 4. Agregar userId al contexto de GraphQL
        GraphQLContext context = request.toGraphQLContext();
        context.put("userId", userId);
        
        // 5. Continuar con la ejecución
        return chain.next(request);
    }
    
    private String extractToken(WebGraphQlRequest request) {
        String authHeader = request.getHeaders().getFirst("Authorization");
        if (authHeader != null && authHeader.startsWith("Bearer ")) {
            return authHeader.substring(7);
        }
        return null;
    }
}
```

### 5.2 Uso del Contexto en Resolvers

```java
@QueryMapping
public List<Portfolio> myPortfolios(GraphQLContext context) {
    // Obtener userId del contexto
    String userId = context.get("userId");
    
    // Retornar solo portfolios del usuario autenticado
    return portfolioService.findByUserId(userId);
}
```

### 5.3 Autorización a Nivel de Campo

**Escenario:** Campo `ownerEmail` solo visible para el dueño.

```java
@SchemaMapping(typeName = "Portfolio", field = "ownerEmail")
public String ownerEmail(
    Portfolio portfolio,
    GraphQLContext context
) {
    String requestUserId = context.get("userId");
    
    // Verificar que el usuario sea el dueño
    if (!portfolio.getOwnerId().equals(requestUserId)) {
        throw new GraphQLException("Access denied");
    }
    
    return portfolio.getOwnerEmail();
}
```

**Query:**
```graphql
{
  portfolio(id: "portfolio-001") {
    name
    ownerEmail  # Solo visible para el dueño
  }
}
```

**Respuesta (si NO eres el dueño):**
```json
{
  "errors": [
    {
      "message": "Access denied",
      "path": ["portfolio", "ownerEmail"]
    }
  ],
  "data": {
    "portfolio": {
      "name": "Growth Portfolio",
      "ownerEmail": null
    }
  }
}
```

### 5.4 API Keys

**Alternativa a JWT:** API Keys para servicios externos.

```java
@Component
public class ApiKeyInterceptor implements WebGraphQlInterceptor {
    
    @Override
    public Mono<WebGraphQlResponse> intercept(
        WebGraphQlRequest request, 
        Chain chain
    ) {
        String apiKey = request.getHeaders().getFirst("X-API-Key");
        
        if (apiKey == null || !isValidApiKey(apiKey)) {
            throw new GraphQLException("Invalid API Key");
        }
        
        return chain.next(request);
    }
    
    private boolean isValidApiKey(String apiKey) {
        // Validar contra base de datos
        return apiKeyRepository.existsByKey(apiKey);
    }
}
```

---

## 6. Ejemplos de Autenticación y Autorización

### Ejemplo 1: Solo usuarios autenticados

```java
@QueryMapping
public List<Portfolio> myPortfolios(GraphQLContext context) {
    // Verificar que hay usuario autenticado
    String userId = context.get("userId");
    if (userId == null) {
        throw new GraphQLException("Authentication required");
    }
    
    return portfolioService.findByUserId(userId);
}
```

### Ejemplo 2: Roles y permisos

```java
@MutationMapping
public PortfolioResponse deletePortfolio(
    @Argument String id,
    GraphQLContext context
) {
    String userId = context.get("userId");
    String role = context.get("role");
    
    // Solo ADMIN puede borrar
    if (!"ADMIN".equals(role)) {
        throw new GraphQLException("Admin role required");
    }
    
    portfolioService.delete(id);
    return new PortfolioResponse(true, "Deleted");
}
```

### Ejemplo 3: Rate limiting

```java
@QueryMapping
public List<Asset> assets(
    @Argument String portfolioId,
    GraphQLContext context
) {
    String userId = context.get("userId");
    
    // Verificar rate limit (ej: 100 requests/hora)
    if (!rateLimiter.allowRequest(userId)) {
        throw new GraphQLException("Rate limit exceeded");
    }
    
    return assetService.findByPortfolioId(portfolioId);
}
```

---

## 7. Resumen de Sección 1.5

### Tipado Fuerte:

- ✅ **Validación automática** antes de ejecutar
- ✅ Tipos: `ID`, `String`, `Int`, `Float`, `Boolean`
- ✅ Errores claros: "Expected Float, got String"
- ✅ Reduce carga operativa del backend

### Nullabilidad:

- ✅ `!` = **non-nullable** (nunca null)
- ✅ Sin `!` = **nullable** (puede ser null)
- ✅ Garantías del sistema: `String!` siempre tiene valor
- ✅ Listas: `[Asset!]!` = lista y elementos non-null

### Enums:

- ✅ Valores predefinidos y validados
- ✅ Auto-completado en IDEs
- ✅ Type-safe en código

### Introspection:

- ✅ Schema consultable programáticamente
- ✅ Auto-documentación built-in
- ✅ Herramientas usan introspection
- ⚠️ Desactivar en producción

### Seguridad Básica:

- ✅ **JWT:** Autenticación con tokens
- ✅ **Context:** Propagar userId a resolvers
- ✅ **Field-level auth:** Restringir campos específicos
- ✅ **API Keys:** Para servicios externos
- ✅ **Rate limiting:** Prevenir abuso

---

# 📝 CONCLUSIÓN DEL CAPÍTULO 1

## Lo que Aprendimos

### Sección 1.1: REST vs GraphQL
- Problemas de overfetching y underfetching
- Endpoint único vs múltiples endpoints
- Declarativo vs imperativo
- Reducción de tráfico y latencia

### Sección 1.2: Componentes Base
- Schema como contrato explícito
- Types, Queries, Mutations, Resolvers
- Consistencia semántica
- Response wrappers

### Sección 1.3: Anidación y Variables
- Consultas anidadas multi-nivel
- Variables tipadas y reusables
- Validación automática
- Seguridad anti-injection

### Sección 1.4: Filtros y Paginación
- Filtrado flexible con input types
- Ordenamiento customizable
- Cursor-based pagination
- Límites del backend

### Sección 1.5: Tipado y Seguridad
- Tipado fuerte y validación
- Nullabilidad con `!`
- Introspection
- JWT y field-level authorization

---

