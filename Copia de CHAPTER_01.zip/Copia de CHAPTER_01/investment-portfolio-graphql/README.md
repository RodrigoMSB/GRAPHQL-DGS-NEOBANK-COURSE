# 📘 CHAPTER 01: Fundamentos de GraphQL y Contexto Corporativo

**Duración:** 2 horas (5 secciones × 30 min)  
**Nivel:** Desarrolladores backend con experiencia  
**Stack:** Spring Boot 3.4.5 + GraphQL Java 24.x + Java 17

---

## 📚 DOCUMENTACIÓN COMPLETA

- **[📖 TEORÍA COMPLETA](DOCUMENTACION/TEORIA.md)** - Conceptos detallados de cada sección
- **[🚀 GUÍA POSTMAN](DOCUMENTACION/POSTMAN_GUIDE.md)** - Cómo usar la collection de Postman

---

## 🎯 OBJETIVO DEL CAPÍTULO

Introducir GraphQL desde fundamentos hasta implementación práctica, usando un caso real de **Investment Portfolio Tracker** (NeoBank). Los alumnos comprenderán **POR QUÉ GraphQL existe**, **QUÉ problemas resuelve** y **CÓMO implementarlo** con Spring Boot.

---

## 📋 CONTENIDO DEL CAPÍTULO

### Sección 1.1 — De REST a GraphQL (30 min)
**Conceptos clave:**
- ❌ Overfetching: REST devuelve más datos de los necesarios
- ❌ Underfetching: REST requiere múltiples llamadas HTTP
- ✅ Endpoint único: `/graphql` vs múltiples endpoints REST
- ✅ Declarativo: El cliente pide exactamente lo que necesita

**Ejemplo práctico:** Comparación lado a lado REST vs GraphQL para obtener portfolios de inversión.

---

### Sección 1.2 — Componentes y lenguaje base (30 min)
**Los 5 pilares de GraphQL:**
1. **Schema:** Contrato explícito entre cliente y servidor
2. **Types:** Portfolio, Asset, Performance (tipos del dominio)
3. **Queries:** Operaciones de lectura (`myPortfolios`, `portfolio(id)`)
4. **Mutations:** Operaciones de escritura (`createPortfolio`, `addAsset`)
5. **Resolvers:** Lógica de conexión entre queries y fuentes de datos

**Ejemplo práctico:** Schema completo de Investment Portfolio con tipos anidados.

---

### Sección 1.3 — Consultas anidadas y uso de variables (30 min)
**Conceptos clave:**
- Anidación: `portfolio → assets → performance` (3 niveles)
- Variables tipadas: `query($id: ID!)` para reusabilidad
- Validación automática: GraphQL valida tipos antes de ejecutar
- Consultas parametrizadas seguras (anti SQL-injection)

**Ejemplo práctico:** Obtener portfolio completo con assets y performance en una sola query.

---

### Sección 1.4 — Filtros, orden y paginación (30 min)
**Conceptos clave:**
- Filtrado: `filter: {assetType: STOCK, minValue: 5000}`
- Ordenamiento: `sort: {field: TOTAL_VALUE, direction: DESC}`
- Paginación cursor-based: `pagination: {limit: 10, after: "cursor"}`
- Límites del backend: Protección contra queries costosas

**Ejemplo práctico:** Query compleja combinando filtro + orden + paginación.

---

### Sección 1.5 — Tipado, nullabilidad y seguridad básica (30 min)
**Conceptos clave:**
- Tipado fuerte: `Float!`, `String!`, `[Asset!]!`
- Non-nullable (`!`): Campos obligatorios validados automáticamente
- Enums: `AssetType: STOCK | CRYPTO | ETF | BOND | COMMODITY`
- Seguridad básica: JWT, API Keys, field-level authorization

**Ejemplo práctico:** Validación automática de tipos + autenticación JWT.

---

## 🚀 QUICK START

### Prerrequisitos
```bash
- Java 17+ (LTS)
- Maven 3.8+
- Git
- curl (para testing)
- Editor de código (IntelliJ IDEA, VS Code, etc.)
```

### 1. Clonar y posicionarse en el capítulo
```bash
git clone <repo-url>
cd GRAPHQL-DGS-NEOBANK-COURSE/CHAPTER_01/investment-portfolio-graphql
```

### 2. Compilar el proyecto
```bash
mvn clean install
```

### 3. Ejecutar la aplicación
```bash
mvn spring-boot:run
```

**Salida esperada:**
```
  .   ____          _            __ _ _
 /\\ / ___'_ __ _ _(_)_ __  __ _ \ \ \ \
( ( )\___ | '_ | '_| | '_ \/ _` | \ \ \ \
 \\/  ___)| |_)| | | | | || (_| |  ) ) ) )
  '  |____| .__|_| |_|_| |_\__, | / / / /
 =========|_|==============|___/=/_/_/_/
 :: Spring Boot ::               (v3.4.5)

Started InvestmentPortfolioGraphqlApplication in 2.145 seconds
```

### 4. Verificar que funciona
```bash
curl http://localhost:8080
# Debe responder con el servidor activo
```

---

## 🧪 TESTING CON SCRIPT AUTOMATIZADO

### Ejecutar todos los tests (MODO CLASE)
```bash
# Modo interactivo (pausa entre tests para explicar)
./test-chapter01.sh
```

**Uso en clase:**
1. Ejecutas el script
2. Aparece el test #1 con su resultado
3. Presionas Enter
4. Explicas el concepto
5. Presionas Enter para el siguiente test
6. Repites hasta completar las 5 secciones

### Ejecutar todos los tests (MODO RÁPIDO)
```bash
# Modo silencioso (sin pausas, para CI/CD)
./test-chapter01.sh -s
```

**Resultado esperado:**
```
================================================================================
📊 RESUMEN DE RESULTADOS
================================================================================
Total de tests ejecutados: 34
✅ Tests exitosos: 34
❌ Tests fallidos: 0

🎉 ¡TODOS LOS TESTS PASARON! Chapter 01 completo y funcional.

Cobertura del temario:
  ✅ Sección 1.1 - REST vs GraphQL (7 tests)
  ✅ Sección 1.2 - Componentes base (9 tests)
  ✅ Sección 1.3 - Anidación y variables (5 tests)
  ✅ Sección 1.4 - Filtros y paginación (7 tests)
  ✅ Sección 1.5 - Tipado y seguridad (6 tests)

TOTAL: 34 tests automatizados
```

---

## 🎓 CÓMO USAR ESTE PROYECTO EN CLASE

### Metodología: "Show, Don't Build"

Este proyecto está diseñado para **DEMOSTRAR** GraphQL funcionando, no para construir desde cero durante la clase.

**Flujo recomendado por sección:**

#### 1. Contextualización (5 min)
- Explica el problema que resuelve la sección
- Muestra el código relevante en el editor

#### 2. Demostración en vivo (15 min)
- Ejecuta `./test-chapter01.sh` en modo interactivo
- Para en cada test para explicar:
  - Qué hace la query/mutation
  - Qué resultado esperas
  - Por qué es importante

#### 3. Exploración GraphiQL (5 min)
- Abre http://localhost:8080/graphiql
- Deja que los alumnos prueben queries
- Muestra introspection y auto-documentación

#### 4. Código deep-dive (5 min)
- Muestra el resolver correspondiente
- Explica cómo conecta con el servicio
- Responde preguntas

**Total:** 30 min por sección × 5 secciones = 2.5 horas (flexibilidad para preguntas)

---

## 🔍 ENDPOINTS DISPONIBLES

### GraphQL Endpoint
```
POST http://localhost:8080/graphql
Content-Type: application/json

{
  "query": "{ myPortfolios { name } }"
}
```

### GraphiQL Interface (Playground)
```
http://localhost:8080/graphiql
```

### REST Endpoints (para comparación)
```
GET  http://localhost:8080/api/rest/portfolios
GET  http://localhost:8080/api/rest/portfolios/{id}
GET  http://localhost:8080/api/rest/portfolios/{id}/assets
GET  http://localhost:8080/api/rest/portfolios/{id}/performance
```

---

## 📊 QUERIES DE EJEMPLO

### Query básica
```graphql
{
  myPortfolios {
    id
    name
    totalValue
  }
}
```

### Query con argumentos
```graphql
{
  portfolio(id: "portfolio-001") {
    name
    totalValue
    assets {
      symbol
      currentPrice
      profitLossPercent
    }
  }
}
```

### Query anidada compleja
```graphql
{
  portfolio(id: "portfolio-001") {
    name
    assets {
      symbol
      name
      assetType
    }
    performance {
      totalReturn
      yearReturn
      bestPerformer {
        symbol
        profitLossPercent
      }
    }
  }
}
```

### Query con variables
```graphql
query GetPortfolio($id: ID!) {
  portfolio(id: $id) {
    name
    totalValue
  }
}

# Variables:
{
  "id": "portfolio-001"
}
```

### Query con filtros y paginación
```graphql
{
  assets(
    portfolioId: "portfolio-001"
    filter: {
      assetType: STOCK
      minValue: 5000
    }
    sort: {
      field: PROFIT_LOSS_PERCENT
      direction: DESC
    }
    pagination: {
      limit: 5
    }
  ) {
    totalCount
    edges {
      node {
        symbol
        totalValue
        profitLossPercent
      }
    }
    pageInfo {
      hasNextPage
      endCursor
    }
  }
}
```

### Mutation - Crear portfolio
```graphql
mutation {
  createPortfolio(input: {
    name: "Tech Growth Portfolio"
  }) {
    success
    message
    portfolio {
      id
      name
      totalValue
    }
  }
}
```

### Mutation - Agregar asset
```graphql
mutation {
  addAsset(input: {
    portfolioId: "portfolio-001"
    symbol: "NVDA"
    assetType: STOCK
    quantity: 10
    buyPrice: 500
  }) {
    success
    message
  }
}
```

---

## 📁 ESTRUCTURA DEL PROYECTO

```
investment-portfolio-graphql/
│
├── src/
│   ├── main/
│   │   ├── java/com/neobank/graphql/
│   │   │   ├── InvestmentPortfolioGraphqlApplication.java
│   │   │   │
│   │   │   ├── config/                    # Configuración
│   │   │   │   ├── GraphQLConfig.java     # Configuración GraphQL
│   │   │   │   └── SecurityConfig.java    # Seguridad JWT
│   │   │   │
│   │   │   ├── controller/                # Controllers
│   │   │   │   ├── graphql/               # GraphQL resolvers
│   │   │   │   │   ├── PortfolioQueryResolver.java
│   │   │   │   │   ├── PortfolioMutationResolver.java
│   │   │   │   │   ├── AssetQueryResolver.java
│   │   │   │   │   └── AssetMutationResolver.java
│   │   │   │   │
│   │   │   │   └── rest/                  # REST endpoints (comparación)
│   │   │   │       └── PortfolioRestController.java
│   │   │   │
│   │   │   ├── model/                     # Domain models
│   │   │   │   ├── Portfolio.java
│   │   │   │   ├── Asset.java
│   │   │   │   ├── Performance.java
│   │   │   │   ├── AssetType.java         # Enum
│   │   │   │   └── input/                 # Input types
│   │   │   │       ├── CreatePortfolioInput.java
│   │   │   │       ├── AddAssetInput.java
│   │   │   │       ├── AssetFilterInput.java
│   │   │   │       └── PaginationInput.java
│   │   │   │
│   │   │   ├── service/                   # Business logic
│   │   │   │   ├── PortfolioService.java
│   │   │   │   ├── AssetService.java
│   │   │   │   └── MockDataService.java   # Datos de prueba
│   │   │   │
│   │   │   └── response/                  # Response wrappers
│   │   │       ├── PortfolioResponse.java
│   │   │       ├── AssetResponse.java
│   │   │       └── AssetConnection.java   # Paginación
│   │   │
│   │   └── resources/
│   │       ├── application.properties     # Configuración Spring
│   │       └── graphql/                   # GraphQL schemas
│   │           └── schema.graphqls        # Schema principal
│   │
│   └── test/
│       └── java/com/neobank/graphql/
│           └── InvestmentPortfolioGraphqlApplicationTests.java
│
├── pom.xml                                # Maven dependencies
├── test-chapter01.sh                      # Script de testing
└── README.md                              # Este archivo
```

---

## 🔧 TECNOLOGÍAS UTILIZADAS

### Core Stack
- **Java 17** (LTS hasta 2029)
- **Spring Boot 3.4.5** (última estable)
- **Spring for GraphQL 1.4.x** (integración oficial)
- **GraphQL Java 24.x** (motor GraphQL)

### Dependencias principales
```xml
<!-- GraphQL -->
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-graphql</artifactId>
</dependency>

<!-- Web (REST comparison) -->
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-web</artifactId>
</dependency>

<!-- Security (JWT) -->
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-security</artifactId>
</dependency>

<!-- JWT -->
<dependency>
    <groupId>io.jsonwebtoken</groupId>
    <artifactId>jjwt-api</artifactId>
    <version>0.12.6</version>
</dependency>

<!-- Lombok -->
<dependency>
    <groupId>org.projectlombok</groupId>
    <artifactId>lombok</artifactId>
</dependency>
```

---

## 📚 CONCEPTOS ENSEÑADOS

### ✅ Nivel Básico (Secciones 1.1 - 1.2)
- Diferencias REST vs GraphQL
- Overfetching y underfetching
- Schema como contrato
- Types, Queries, Mutations
- Resolvers básicos

### ✅ Nivel Intermedio (Secciones 1.3 - 1.4)
- Consultas anidadas
- Variables tipadas
- Filtrado y ordenamiento
- Paginación cursor-based
- Validación automática

### ✅ Nivel Avanzado (Sección 1.5)
- Tipado fuerte y nullabilidad
- Enums y validación
- Introspection
- Seguridad básica (JWT)
- Field-level authorization

---

## 🎯 COBERTURA DE TESTS

### Sección 1.1 - REST vs GraphQL (7 tests)
- ✅ Overfetching: REST devuelve todo
- ✅ GraphQL selectivo: Solo campos pedidos
- ✅ Underfetching: REST múltiples llamadas
- ✅ GraphQL eficiente: Una sola llamada
- ✅ Endpoint único vs múltiples endpoints

### Sección 1.2 - Componentes base (9 tests)
- ✅ Schema types validados
- ✅ Queries simples y con argumentos
- ✅ Mutations (create, add, remove)
- ✅ Enums validados
- ✅ Resolvers funcionando

### Sección 1.3 - Anidación y variables (5 tests)
- ✅ Anidación nivel 1 (portfolio → assets)
- ✅ Anidación nivel 2 (portfolio → performance → bestPerformer)
- ✅ Variables tipadas ($id: ID!)
- ✅ Validación de variables
- ✅ Múltiples relaciones en una query

### Sección 1.4 - Filtros y paginación (7 tests)
- ✅ Filtrado por tipo (AssetType)
- ✅ Filtrado por rango (minValue)
- ✅ Ordenamiento DESC
- ✅ Ordenamiento por profit
- ✅ Paginación cursor-based
- ✅ Query compleja (filtro + orden + paginación)
- ✅ Límites controlados por backend

### Sección 1.5 - Tipado y seguridad (6 tests)
- ✅ Validación de tipos (Float!, String!)
- ✅ Non-nullable fields
- ✅ Enum validation
- ✅ Introspection habilitada
- ✅ Validación de argumentos obligatorios
- ✅ Estructura de respuesta consistente

**TOTAL: 34 tests automatizados** 🎉

---

## 🐛 TROUBLESHOOTING

### Problema: Puerto 8080 ya en uso
```bash
# Encuentra y mata el proceso
lsof -i :8080
kill -9 <PID>

# O cambia el puerto en application.properties
server.port=8081
```

### Problema: Tests fallan en Windows
```bash
# Asegúrate de usar GitBash, no CMD
# En GitBash:
bash test-chapter01.sh -s
```

### Problema: "mvn: command not found"
```bash
# Instala Maven
# Mac:
brew install maven

# Linux:
sudo apt-get install maven

# Windows:
# Descarga desde https://maven.apache.org/download.cgi
```

### Problema: Java version incorrecta
```bash
# Verifica versión
java -version

# Debe mostrar Java 17 o superior
# Si no, instala Java 17:
# Mac:
brew install openjdk@17

# Linux:
sudo apt-get install openjdk-17-jdk
```

### Problema: Script .sh no ejecutable
```bash
# Dar permisos de ejecución
chmod +x test-chapter01.sh
```

---

## 📝 NOTAS PEDAGÓGICAS

### Para el instructor:

1. **Tiempo es ajustado:** 30 min por sección es el mínimo. Deja buffer para preguntas.

2. **No construyas desde cero:** El código ya está completo. Enfócate en EXPLICAR, no en escribir.

3. **Usa GraphiQL:** Es tu mejor herramienta pedagógica. Auto-documentación + validación en vivo.

4. **Compara siempre con REST:** Los alumnos conocen REST. Usa eso como puente.

5. **Tests son tu guía:** Cada test representa un concepto. Úsalos como checklist.

6. **Prioriza conceptos sobre código:** Que entiendan el "por qué" antes del "cómo".

### Para el alumno:

1. **No te preocupes por memorizar:** Enfócate en entender los conceptos.

2. **Experimenta en GraphiQL:** Es tu sandbox. Prueba queries locas.

3. **Lee los tests:** Muestran casos de uso reales y validaciones.

4. **Pregunta mucho:** Este es un capítulo denso. No hay preguntas tontas.

---

## 🚀 PRÓXIMOS PASOS

Después de completar este capítulo, los alumnos estarán listos para:

- **CHAPTER_02:** Cashback Rewards Schema (diseño avanzado de schemas)
- **CHAPTER_03:** DGS Framework completo con DataLoader
- **CHAPTER_04:** Persistencia con JPA y transacciones
- **CHAPTER_05:** Apollo Federation (arquitectura distribuida)

---

## 📖 RECURSOS ADICIONALES

### Documentación oficial
- [GraphQL Specification](https://spec.graphql.org/)
- [GraphQL Java](https://www.graphql-java.com/)
- [Spring for GraphQL](https://docs.spring.io/spring-graphql/reference/)

### Herramientas recomendadas
- [GraphiQL](http://localhost:8080/graphiql) - Playground incluido
- [Postman](https://www.postman.com/) - Testing de APIs
- [Insomnia](https://insomnia.rest/) - Cliente GraphQL

### Lecturas complementarias
- [GraphQL Best Practices](https://graphql.org/learn/best-practices/)
- [Schema Design Guide](https://www.apollographql.com/docs/apollo-server/schema/schema/)

---

## 👥 CONTRIBUCIONES

Este proyecto es parte del curso **"El Mejor Curso de GraphQL del Mundo"**.

**Instructor:** [Tu nombre]  
**Versión:** 1.0.0  
**Última actualización:** Noviembre 2025

---

## 📄 LICENCIA

Este material es de uso educativo exclusivo para el curso de GraphQL.

---

## ✨ CHANGELOG

### v1.0.0 (2025-11-15)
- ✅ Stack actualizado a Spring Boot 3.4.5 + GraphQL Java 24.x
- ✅ 34 tests automatizados funcionando
- ✅ Script portable Mac/Linux/Windows
- ✅ Cobertura completa del temario (5 secciones)
- ✅ README completo con instrucciones detalladas